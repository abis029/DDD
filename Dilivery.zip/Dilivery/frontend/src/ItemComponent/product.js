import { useState } from "react";
import axios from "axios";
import './additem.css';
import { useNavigate } from 'react-router-dom';

function Product() {
    const navigate = useNavigate();
    const [order, setOrder] = useState({
        emaill: "",
        fnamee: "",
        lnamee: "",
        habitual_residence: "",
        address: "",
        p_nbb: "",
        zipcode: "",
    });

    const [errors, setErrors] = useState({});

    const handleOnChange = (e) => {
        const { value, name } = e.target;

        if ((name === "p_nbb" || name === "zipcode") && value && isNaN(value)) {
            setErrors((prev) => ({
                ...prev,
                [name]: `${name === "p_nbb" ? "Phone number" : "Zip code"} must be numeric.`,
            }));
        } else {
            setErrors((prev) => ({
                ...prev,
                [name]: "",
            }));
            setOrder((prev) => ({
                ...prev,
                [name]: value,
            }));
        }
    };

    const validate = () => {
        const newErrors = {};

        if (!order.emaill) {
            newErrors.emaill = "Email is required.";
        } else if (!/\S+@\S+\.\S+/.test(order.emaill)) {
            newErrors.emaill = "Email address is invalid.";
        }

        if (!order.fnamee) newErrors.fnamee = "First name is required.";
        if (!order.lnamee) newErrors.lnamee = "Last name is required.";
        if (!order.habitual_residence) newErrors.habitual_residence = "Habitual residence is required.";
        if (!order.address) newErrors.address = "Address is required.";
        if (!order.p_nbb) {
            newErrors.p_nbb = "Phone number is required.";
        } else if (isNaN(order.p_nbb)) {
            newErrors.p_nbb = "Phone number must be numeric.";
        } else if (order.p_nbb.length < 10) {
            newErrors.p_nbb = "Phone number must be at least 10 digits long.";
        }

        if (!order.zipcode) {
            newErrors.zipcode = "Zip code is required.";
        } else if (isNaN(order.zipcode)) {
            newErrors.zipcode = "Zip code must be numeric.";
        } else if (order.zipcode.length < 5) {
            newErrors.zipcode = "Zip code must be at least 5 digits long.";
        }

        return newErrors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const newErrors = validate();
        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
            return;
        }

        try {
            const response = await axios.post("http://localhost:8020/item_create", order);
            console.log(response.data);
            alert("Successfully added!");
            navigate("/itemdetails");
            setOrder({
                emaill: "",
                fnamee: "",
                lnamee: "",
                habitual_residence: "",
                address: "",
                p_nbb: "",
                zipcode: "",
            });
            setErrors({});
        } catch (error) {
            console.error("There was an error adding the item:", error);
        }
    };

    return (
        <div className="add-product">
            <div className="line-container">
                <hr className="line" />
                <span className="line-text"><a href="/itemdetails">Delivery</a></span>
            </div>
            <h2>User</h2>
            <form onSubmit={handleSubmit}>
                <label>Email:</label>
                <input
                    type="text"
                    id="emaill"
                    name="emaill"
                    value={order.emaill}
                    onChange={handleOnChange}
                />
                {errors.emaill && <span className="error">{errors.emaill}</span>}
                <br />

                <label>First Name:</label>
                <input
                    type="text"
                    id="fnamee"
                    name="fnamee"
                    value={order.fnamee}
                    onChange={handleOnChange}
                />
                {errors.fnamee && <span className="error">{errors.fnamee}</span>}
                <br />

                <label>Last Name:</label>
                <input
                    type="text"
                    id="lnamee"
                    name="lnamee"
                    value={order.lnamee}
                    onChange={handleOnChange}
                />
                {errors.lnamee && <span className="error">{errors.lnamee}</span>}
                <br />

                <label>Habitual Residence:</label>
                <input
                    type="text"
                    id="habitual_residence"
                    name="habitual_residence"
                    value={order.habitual_residence}
                    onChange={handleOnChange}
                />
                {errors.habitual_residence && <span className="error">{errors.habitual_residence}</span>}
                <br />

                <label>Address:</label>
                <input
                    type="text"
                    id="address"
                    name="address"
                    value={order.address}
                    onChange={handleOnChange}
                />
                {errors.address && <span className="error">{errors.address}</span>}
                <br />

                <label>Phone Number:</label>
                <input
                    type="text"
                    id="p_nbb"
                    name="p_nbb"
                    value={order.p_nbb}
                    onChange={handleOnChange}
                />
                {errors.p_nbb && <span className="error">{errors.p_nbb}</span>}
                <br />

                <label>Zip Code:</label>
                <input
                    type="text"
                    id="zipcode"
                    name="zipcode"
                    value={order.zipcode}
                    onChange={handleOnChange}
                />
                {errors.zipcode && <span className="error">{errors.zipcode}</span>}
                <br />

                <button type="submit">Submit</button>
            </form>
            <div id='footer'>
                <p>Ant Design @2024 Created by Ant UED</p>
            </div>
        </div>
    );
}

export default Product;
