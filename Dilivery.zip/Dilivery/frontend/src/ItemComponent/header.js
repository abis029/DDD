import './header.css';

function Header() {
    return (
        <div>
            <div className="navbar">
                <a href="/">Home</a>
                <a href="/add-item">Add Details</a>
                <a href="/itemdetails">Dilivery</a>
                <a href="/dilidetails">Dilivery Details</a>
                <a href="/itemdetails">All Details</a>
            </div>
        </div>
    );
}

export default Header;
