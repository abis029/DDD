import { useState } from "react";
import './AdminRegister.css';
import { useNavigate } from "react-router-dom";

function ManagerSignUp() {
    const [order, setOrder] = useState({
        username: "",
        dili_address: "",
        dili_date: "",
        dili_status: "",
        dili_method: "",
        dili_cost: "",
        assignes_personal: "",
        notes: "",
    });

    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const handleOnChange = (e) => {
        const { value, name } = e.target;
        setOrder((prev) => ({
            ...prev,
            [name]: value
        }));
    };

    const validate = () => {
        const newErrors = {};
        if (!order.username.trim()) {
            newErrors.username = "Username is required";
        }
        if (!order.dili_address.trim()) {
            newErrors.dili_address = "Delivery Address is required";
        }
        if (!order.dili_date.trim()) {
            newErrors.dili_date = "Delivery Date is required";
        }
        if (!order.dili_status.trim()) {
            newErrors.dili_status = "Delivery Status is required";
        }
        if (!order.dili_method.trim()) {
            newErrors.dili_method = "Delivery Method is required";
        }
        if (!order.dili_cost.trim()) {
            newErrors.dili_cost = "Delivery Cost is required";
        }
        if (!order.assignes_personal.trim()) {
            newErrors.assignes_personal = "Assigned Personal is required";
        }
        if (!order.notes.trim()) {
            newErrors.notes = "Notes are required";
        }
        return newErrors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const validationErrors = validate();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }

        try {
            const res = await fetch('http://localhost:8020/add_manager', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(order),
            });

            const data = await res.json();

            if (res.ok && data.success) {
                alert("Account created successfully");
                navigate('/');

                const emailResponse = await fetch('/api/auth/manager_send_email', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email: order.email }),
                });

                const emailData = await emailResponse.json();

                if (emailResponse.ok && emailData.success) {
                    console.log("Thank you email sent to:", order.email);
                }
            } else {
                throw new Error(data.message || 'Failed to create account');
            }
        } catch (error) {
            console.log('Something went wrong!', error.message);
        }
    };

    return (
        <div id="package-body">
            <div className="add-order">
                <div id="package-form">
                    <h2><b>Add /Edit Dilivery</b></h2>
                    <form onSubmit={handleSubmit}>
                        <label>Customer Name:</label>
                        <input
                            type="text"
                            id="username"
                            name="username"
                            value={order.username}
                            onChange={handleOnChange}
                        />
                        {errors.username && <p className="error">{errors.username}</p>}

                        <label>Delivery Address:</label>
                        <input
                            type="text"
                            id="dili_address"
                            name="dili_address"
                            value={order.dili_address}
                            onChange={handleOnChange}
                        />
                        {errors.dili_address && <p className="error">{errors.dili_address}</p>}

                        <label>Delivery Date:</label>
                        <input
                            type="date"
                            id="dili_date"
                            name="dili_date"
                            value={order.dili_date}
                            onChange={handleOnChange}
                        />
                        {errors.dili_date && <p className="error">{errors.dili_date}</p>}
 
                        <label>Delivery Status:</label>
                        <select id="dili_status"
                            name="dili_status"
                            value={order.dili_status}
                            onChange={handleOnChange}>
                            <option>Penidng</option>
                            <option>Shipped</option>
                            <option>Delivered</option>
                        </select>
                        
                        {errors.dili_status && <p className="error">{errors.dili_status}</p>}

                        <label>Delivery Method:</label>
                        <input
                            type="text"
                            id="dili_method"
                            name="dili_method"
                            value={order.dili_method}
                            onChange={handleOnChange}
                        />
                        {errors.dili_method && <p className="error">{errors.dili_method}</p>}

                        <label>Delivery Cost $:</label>
                        <input
                            type="text"
                            id="dili_cost"
                            name="dili_cost"
                            value={order.dili_cost}
                            onChange={handleOnChange}
                        />
                        {errors.dili_cost && <p className="error">{errors.dili_cost}</p>}

                        <label>Assigned Personal:</label>
                        <input
                            type="text"
                            id="assignes_personal"
                            name="assignes_personal"
                            value={order.assignes_personal}
                            onChange={handleOnChange}
                        />
                        {errors.assignes_personal && <p className="error">{errors.assignes_personal}</p>}

                        <label>Notes:</label>
                        <textarea
                            id="notes"
                            name="notes"
                            value={order.notes}
                            onChange={handleOnChange}
                        />
                        {errors.notes && <p className="error">{errors.notes}</p>}

                        <button type="submit">Add Dilivery</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default ManagerSignUp;
